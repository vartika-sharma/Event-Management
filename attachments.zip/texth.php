<!DOCTYPE html>
<html>
<head>
<title>
tect question
</title>
<body>


		         <img src="textques.jpg" style="width:1335px;height:650px">
		         <div  style="font-size:25px;font-family:Berlin Sans FB;color:#FFF;position:absolute; top:0px;right:10px;">
Hey!

<br>
<a href = "logout.php">Logout</a>
</div>

		         <div style="position:absolute;top:30px;left:20px ;background-color:rgba(255,255,255,0.5);font-size:55px;font-family:Berlin Sans FB;color:#000;">
				 <table align="center">

				<form method =  "post" id="store_manager" action = "text.php">
				<tr><td>Enter the question:</td><td><input type="text" name="question"></td></tr>
				<tr><td colspan=2><input type="submit" name = "que" value="next question"></td></tr>
				</form>


				<form method = "post" id="store_manager" action = "form_make.php">
				<tr><td colspan=2><input type="submit" name = "type" value="Choose another type:"></td></tr>
			
			    </form>
			    </table>
			    </div>
			    </body>

				

