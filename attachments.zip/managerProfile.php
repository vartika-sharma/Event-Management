<?php
session_start() ;
include "notification.php";
include"heade.html";
?>
<DOCTYPE html>
<html>
<head>
<title>
manager profile</title>
<style>
a:link{
	color: #4d004d;

}
a:visited{
	color: #4d004d;
}

</style>
</script>
</head>
<body bgcolor="#ebebe0">

<img src="headProfile.jpg" width="100%" height="45%">
<div align="center"style="font-family: Rockwell; font-size: 28px">
<br>
<a href="salesh.php">Daily Sales</a>
<br><br>
<a href="form_fill.php">view forms sent to you</a>
<br><br>
<a href="#">view the organisation policies</a>

</div>
</body>
</html>